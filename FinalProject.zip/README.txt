To compile: g++ tsp.cpp

To run: a.out <filename>

<filename> = The input file you want to test.

EX) a.out test-input-1.txt

This will use test-input-1.txt as the input file, and it will output the results
to a file called test-input-1.txt.tour

The time in seconds is outputted to the terminal and the .tour file will hold the results